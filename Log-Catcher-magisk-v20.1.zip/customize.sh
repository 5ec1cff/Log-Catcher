SKIPUNZIP=0
if [ -d "/data/adb/modules/logcat" ]; then
    touch /data/adb/modules/logcat/remove
fi
