# Log-Catcher

Catch boot log and save to /cache/bootlog/boot.log.

When /cache is not exist fallback to /data/local/bootlog/boot.log.

This module can help you to save boot log.

If you don't want to kill the logcat process after boot completed, you can create /data/local/logcatcher/boot.lcs file.
